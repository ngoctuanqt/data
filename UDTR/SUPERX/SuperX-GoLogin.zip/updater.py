import logging
import os
import subprocess
import zipfile
import time
import requests

DIR_PATH = os.path.dirname(os.path.realpath(__file__))
UPDATE_DIR = DIR_PATH + "\\Update"
release_zip = f"{UPDATE_DIR}/update.zip"
exe_file = f"{DIR_PATH}/SuperX-GoLogin.exe"

logFormatter = logging.Formatter("%(asctime)s [%(threadName)-12.12s] [%(levelname)-5.5s] [%(filename)s:%(lineno)d] %(message)s")
fileHandler = logging.FileHandler(f"{DIR_PATH}/superx-gologin-updater.log", "w")
fileHandler.setFormatter(logFormatter)
consoleHandler = logging.StreamHandler()
consoleHandler.setFormatter(logFormatter)
logging.basicConfig(datefmt='%Y-%m-%d:%H:%M:%S', level=logging.INFO, handlers=[fileHandler,consoleHandler])
logger = logging.getLogger("logger")

logger.error(f"Updater release_zip : {release_zip}")
logger.error(f"Updater exe_file : {exe_file}")

def process_exists(process_name):
    try:
        call = 'TASKLIST', '/FI', 'imagename eq %s' % process_name
        # use buildin check_output right away
        output = subprocess.check_output(call).decode()
        # check in last line for process name
        last_line = output.strip().split('\r\n')[-1]
        # because Fail message could be translated
        return last_line.lower().startswith(process_name.lower())
    except:
        return True

def extractReleaseZip():
    try:
        logger.error(f"extractReleaseZip checking app...")
        while process_exists("SuperX-GoLogin.exe"):
            logger.error(f"extractReleaseZip app running...")
            time.sleep(2)
        time.sleep(1)
        logger.error(f"extractReleaseZip extracting...")
        with zipfile.ZipFile(release_zip, 'r') as zip_ref:
            zip_ref.extractall(f"{DIR_PATH}")
            logger.error(f"extractReleaseZip extracted")
        logger.error(f"extractReleaseZip removing...")
        os.remove(release_zip)
        logger.error(f"extractReleaseZip removed")
    except Exception as ex:
        logger.error(f"extractReleaseZip error: {ex}")

def runAppAgain():
    try:
        time.sleep(3)
        logger.error(f"runAppAgain running app...")
        os.startfile(exe_file)
        logger.error(f"runAppAgain run app")
    except Exception as ex:
        logger.error(f"runAppAgain error: {ex}")

extractReleaseZip()
runAppAgain()